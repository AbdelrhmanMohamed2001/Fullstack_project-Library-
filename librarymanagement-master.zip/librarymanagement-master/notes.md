# Try to use classbaseview it is better will save you so much work

# example:

```python

from django.views import generic

class CreateModelView(generic.CreateView):
    template_name = "Template.html"
    model = Your Model
    form_class = YourFormClass

class UpdateModelView(generic.UpdateView):
    template_name = "Template.html"
    model = Your Model
    form_class = YourFormClass

class DetailModelView(generic.Detailiew):
    template_name = "Template.html"
    model = Your Model

class ListModelView(generic.Detailiew):
    template_name = "Template.html"
    model = Your Model
```

# better to use in the template 

* You can make a base.html the extend that base in any other template

## example:

base.html

```html

<!DOCTYPE html>
{% load static %}

<html lang="de">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> {% block title %} {% endblock %} </title>

    <script type="text/javascript" src="{% static 'jQuery-1.12.4/jquery-1.12.4.min.js' %}"></script>
    <link rel="stylesheet" href="{% static 'DataTables/datatables.min.css' %}">
    {% load bootstrap3 %} {% bootstrap_css %} {% bootstrap_javascript %}

    <link rel="stylesheet" href="{% static 'styles/css/index.css' %}">

    {% block styles %}{% endblock %}
</head>

<body>
    <header>
        {% include 'top_navigation.html' %}
    </header>

    <div class="container-fluid" style="margin-top:2%;">
        {% block content %}
        {% endblock %}
        
        {% include 'footer.html %}
    </div>

    <script src="{% static 'DataTables/datatables.min.js' %}"></script>

    {% block extrajs %}{% endblockextrajs %}
</body>

</html>
```
then in any other template a homepage.html will looks like that 

```html
{% extends 'base.html' %}
{% load static %}

{% block title %} StartSeite {% endblock %}
{% block styles %}
{% endblock %}

{% block content %}

<div class="container">
    <div class="text-center">
        <div class="logo">
            <img src="{% static 'images/Sorglos-IT-logo.png' %}">
        </div>
    </div>
    <div id="startpoint" class="text-center">
        <a href="{% url 'customers:list' %}">some link text</a>
    </div>

</div>
{% endblock %}

```